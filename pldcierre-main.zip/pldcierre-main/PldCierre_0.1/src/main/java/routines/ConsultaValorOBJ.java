/**
 * ConsultaValorOBJ.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public class ConsultaValorOBJ  implements java.io.Serializable {
    private java.lang.Long id;

    private java.lang.String[][] listaParam;

    private java.lang.String valor;

    public ConsultaValorOBJ() {
    }

    public ConsultaValorOBJ(
           java.lang.Long id,
           java.lang.String[][] listaParam,
           java.lang.String valor) {
           this.id = id;
           this.listaParam = listaParam;
           this.valor = valor;
    }


    /**
     * Gets the id value for this ConsultaValorOBJ.
     * 
     * @return id
     */
    public java.lang.Long getId() {
        return id;
    }


    /**
     * Sets the id value for this ConsultaValorOBJ.
     * 
     * @param id
     */
    public void setId(java.lang.Long id) {
        this.id = id;
    }


    /**
     * Gets the listaParam value for this ConsultaValorOBJ.
     * 
     * @return listaParam
     */
    public java.lang.String[][] getListaParam() {
        return listaParam;
    }


    /**
     * Sets the listaParam value for this ConsultaValorOBJ.
     * 
     * @param listaParam
     */
    public void setListaParam(java.lang.String[][] listaParam) {
        this.listaParam = listaParam;
    }

    public java.lang.String[] getListaParam(int i) {
        return this.listaParam[i];
    }

    public void setListaParam(int i, java.lang.String[] _value) {
        this.listaParam[i] = _value;
    }


    /**
     * Gets the valor value for this ConsultaValorOBJ.
     * 
     * @return valor
     */
    public java.lang.String getValor() {
        return valor;
    }


    /**
     * Sets the valor value for this ConsultaValorOBJ.
     * 
     * @param valor
     */
    public void setValor(java.lang.String valor) {
        this.valor = valor;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultaValorOBJ)) return false;
        ConsultaValorOBJ other = (ConsultaValorOBJ) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.listaParam==null && other.getListaParam()==null) || 
             (this.listaParam!=null &&
              java.util.Arrays.equals(this.listaParam, other.getListaParam()))) &&
            ((this.valor==null && other.getValor()==null) || 
             (this.valor!=null &&
              this.valor.equals(other.getValor())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getListaParam() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getListaParam());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getListaParam(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getValor() != null) {
            _hashCode += getValor().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultaValorOBJ.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://consultaValorId.cat.ws.izel.net/", "consultaValorOBJ"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("listaParam");
        elemField.setXmlName(new javax.xml.namespace.QName("", "listaParam"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://consultaValorId.cat.ws.izel.net/", "paramXML"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "valor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
