//template routine Java
package routines;

import java.sql.Timestamp;



public class CuentaAhorroOBJ {
	
	private Integer cuenta_id;
	private Integer tipo_transaccion_id;
	private Timestamp fecha;
	private Double monto;
	private Double comision;
	private String descripcion;
	private String num_autorizacion;
	private Integer estatus_id;
	private Integer forma_pago_id;
	private Integer comision_id;
	private Integer estatus_comision_id;
	private String conciliado;
		
	public CuentaAhorroOBJ() {
	}

	public Integer getCuenta_id() {
		return cuenta_id;
	}

	public void setCuenta_id(Integer cuenta_id) {
		this.cuenta_id = cuenta_id;
	}

	public Integer getTipo_transaccion_id() {
		return tipo_transaccion_id;
	}

	public void setTipo_transaccion_id(Integer tipo_transaccion_id) {
		this.tipo_transaccion_id = tipo_transaccion_id;
	}

	public Double getMonto() {
		return monto;
	}

	public void setMonto(Double monto) {
		this.monto = monto;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getNum_autorizacion() {
		return num_autorizacion;
	}

	public void setNum_autorizacion(String num_autorizacion) {
		this.num_autorizacion = num_autorizacion;
	}

	public Integer getEstatus_id() {
		return estatus_id;
	}

	public void setEstatus_id(Integer estatus_id) {
		this.estatus_id = estatus_id;
	}

	public Integer getForma_pago_id() {
		return forma_pago_id;
	}

	public void setForma_pago_id(Integer forma_pago_id) {
		this.forma_pago_id = forma_pago_id;
	}

	public String getConciliado() {
		return conciliado;
	}

	public void setConciliado(String conciliado) {
		this.conciliado = conciliado;
	}

	public Timestamp getFecha() {
		return fecha;
	}

	public void setFecha(Timestamp fecha) {
		this.fecha = fecha;
	}

	public Double getComision() {
		return comision;
	}

	public void setComision(Double comision) {
		this.comision = comision;
	}

	public Integer getComision_id() {
		return comision_id;
	}

	public void setComision_id(Integer comision_id) {
		this.comision_id = comision_id;
	}

	public Integer getEstatus_comision_id() {
		return estatus_comision_id;
	}

	public void setEstatus_comision_id(Integer estatus_comision_id) {
		this.estatus_comision_id = estatus_comision_id;
	}
}
