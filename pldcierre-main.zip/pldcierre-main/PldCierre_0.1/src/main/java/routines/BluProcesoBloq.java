package routines;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.cero.ws.data.Errores;

public class BluProcesoBloq {
	private static String _FORMATO_FECHA_ = "yyyy-MM-dd";
	//private static String _LINEA_PRODUCTO_ = "LINEA_BLU";
	private static String _CONCEPTO_ = "AHO_TIEMPO_TOLERANCIA_TRX";
	private static String _TRANSACCION_ = "TRX_TRANSFERENCIA";

	public static Map<String, String> procesar(Connection conCero, Connection conProcrea, String productoBlu, String fechaHoy) {
		SimpleDateFormat sdf = new SimpleDateFormat(_FORMATO_FECHA_);
		HashMap<String, String> map = new HashMap<>();
		Statement stCero = null;
		Statement stProcrea = null;
		String respuesta = "";

		if(conCero == null || conProcrea == null){
			respuesta = "ERROR - CONEXIONES INVALIDADAS A LAS BD";
			map.put("RESULTADO", "ERROR");
			map.put("DATO", respuesta);
			return map;
		}

		try{
			stCero = conCero.createStatement();
			stProcrea = conProcrea.createStatement();
		}catch(Exception ex){
			ex.printStackTrace();
			respuesta = "ERROR - EN ESTABLECER LAS CONEXIONES A LAS BD";
			map.put("RESULTADO", "ERROR");
			map.put("DATO", respuesta);
			return map;
		}

		try{
			ConceptosOBJ conObj = getConceptos(stCero, productoBlu, _CONCEPTO_);
			List<TiposDocumentosOBJ> lstTiposDoc = getTiposDocumentos(stCero, productoBlu);
			List<CuentasOBJ> lstCuentas = getCuenta(conCero, stProcrea, stCero, productoBlu, fechaHoy, conObj.getDias());



			if(lstCuentas == null){
				respuesta = "SIN CUENTAS PARA BLOQUEAR";
				map.put("RESULTADO", "ERROR");
				map.put("DATO", respuesta);
				return map;
			}

			List<CtaBloquedaOBJ> lstCtaBloq = null;
			for(CuentasOBJ cta : lstCuentas){
				CtaBloquedaOBJ  ctaBloq = new CtaBloquedaOBJ();
				String resultado = "";

				resultado += String.format("\n%s - Cuenta: %s, clabe: %s  - : %s",
						cta.getTipoCliente(), cta.getCuenta(), cta.getClabe_interbancaria(), "EXPEDIENTE INCOMPLETO O NO VERIFICADO");
				
				ctaBloq.setCuenta(cta.getCuenta());
				for(TiposDocumentosOBJ doc : lstTiposDoc){
					ExpedientesOBJ exp = getExpediente(stCero, cta.getCuenta(), doc.getClave());
					if(cta.getExpedientes() == null) cta.iniciaExpedientes();
					cta.getExpedientes().add(exp);
					if(exp == null){
						/*
						resultado += String.format("\n\t\t %s - Cuenta: %s, clabe: %s  - : %s",
								cta.getTipoCliente(), cta.getCuenta(), cta.getClabe_interbancaria(), "EXPEDIENTE INCOMPLETO O NO VERIFICADO");
						*/		
						/*
						resultado += String.format("\n %s - Cuenta: %s, Clabe: %s, Documento: %s, %s - Observaciones: %s",
								cta.getTipoCliente(), cta.getCuenta(), cta.getClabe_interbancaria(), doc.getClave(), doc.getDescripcion() , "NO ESTA CARGADO EL DOCUMENTO");
						*/
					}else{
						//if("N".equals(_T(exp.getVerificado()))){
						/*
						resultado += String.format("\n\t\t %s - Cuenta: %s, clabe: %s  - : %s",
								cta.getTipoCliente(), cta.getCuenta(), cta.getClabe_interbancaria(), "EXPEDIENTE INCOMPLETO O NO VERIFICADO");
						*/		
						/*
						resultado += String.format("\n %s - Cuenta: %s, Clabe: %s, Documento: %s,  %s  - Observaciones: %s",
								cta.getTipoCliente(), cta.getCuenta(), cta.getClabe_interbancaria(), exp.getClave(), exp.getDescripcion(), exp.getObservaciones());
						*/		
						//}
					}
					//System.out.println("RESULTADOS 0 : " + resultado);
				}
				
				if(cta.getDependientes() != null){
					resultado += "\n\t\t--CUENTAS DEPENDIENDES BLOQUEADAS";
					resultado += "\n\t\t---------------------------------";
					for(CuentasOBJ ctaDep : cta.getDependientes()){
						resultado += String.format("\n\t\t %s - Cuenta: %s, clabe: %s  - : %s",
								ctaDep.getTipoCliente(), ctaDep.getCuenta(), ctaDep.getClabe_interbancaria(), "BLOQUEO POR ASOCIACION DE CUENTA");
					}
				}
				
				ctaBloq.setObservaciones(resultado);
				if(lstCtaBloq == null) lstCtaBloq = new ArrayList<>();
				lstCtaBloq.add(ctaBloq);

				Boolean ok = insertBitacora(conCero, String.format("Bloqueo de Cta : %s", ctaBloq.getCuenta()), ctaBloq.getObservaciones());
			}

			if(lstCtaBloq == null){
				respuesta = "SIN CUENTAS PARA BLOQUEAR";
				map.put("RESULTADO", "ERROR");
				map.put("DATO", respuesta);
				return map;
			}

			respuesta = "";
			map.put("RESULTADO", "OK");
			for(CtaBloquedaOBJ obj: lstCtaBloq){
				respuesta += String.format("\n%s", obj.getObservaciones());
				//System.out.println("OBSERVACIONES : " + respuesta);
			}

			//System.out.println("RESULTADOS 1: " + respuesta);


			map.put("DATO", respuesta);	
		}catch(Exception ex){
			ex.printStackTrace();
			respuesta = "ERROR - " + ex.getMessage();
			map.put("RESULTADO", "ERROR");
			map.put("DATO", respuesta);
		}

		return map;
	}

	private static ConceptosOBJ getConceptos(Statement stCero, String claveProducto, String concepto){
		ConceptosOBJ obj = null;
		System.out.println(".... OBTIENE LOS CONCEPTOS DE LA TABLA CONCEPTOS PRODUCTO");
		try{
			String sqlConc = "SELECT " +
					"PR.ID, " +
					"PR.CLAVE, " + 
					"PR.DESCRIPCION, " + 
					"ES.DESCRIPCION AS ESTATUS, " +
					"CO.CLAVE AS CONC_CLAVE, " +
					"CO.DESCRIPCION AS CONCEPTO, " +
					"CAST(COALESCE(DA.VALOR,'0') AS INTEGER) AS DIAS " +
					"FROM PRODUCTOS.PRPRODUCTOS_AHORRO PR " +
					"LEFT JOIN NUCLEOCENTRAL.NCESTATUS ES oN ES.ID = PR.ESTATUS_ID " +
					"LEFT JOIN PRODUCTOS.PRPRODUCTOS_AHORRO_DATOS DA ON DA.PRODUCTO_ID = PR.ID " +
					"LEFT JOIN NUCLEOCENTRAL.NCCONCEPTOS CO ON CO.ID = DA.CONCEPTO_ID " +
					"WHERE PR.CLAVE = '$PRODUCTO' " +
					"AND ES.DESCRIPCION = 'ALTA' " +
					"AND CO.CLAVE = '$CONCEPTO' " +
					"LIMIT 1";

			//"AND CO.CLAVE = 'AHO_TIEMPO_TOLERANCIA_TRX' " +

			sqlConc = sqlConc.replace("$PRODUCTO", claveProducto).replace("$CONCEPTO", concepto);

			System.out.println(sqlConc);

			ResultSet res = stCero.executeQuery(sqlConc);
			while(res.next()){
				obj = new ConceptosOBJ();
				obj.setId(res.getInt("ID"));
				obj.setClave(res.getString("CLAVE"));
				obj.setDescripcion(res.getString("DESCRIPCION"));
				obj.setEstatus(res.getString("ESTATUS"));
				obj.setConc_clave(res.getString("CONC_CLAVE"));
				obj.setConcepto(res.getString("CONCEPTO"));
				obj.setDias(res.getInt("DIAS"));
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return obj;
	}

	private static List<TiposDocumentosOBJ> getTiposDocumentos(Statement stCero, String clave){
		List<TiposDocumentosOBJ> lst = null;
		System.out.println(".... OBTIENE LOS TIPOS DE DOCUMENTOS");
		try{
			String sqlConc = "SELECT " +
					"PD.DOCUMENTO_ID, " +
					"PD.OBLIGATORIO, " +
					"DOC.CLAVE, " +
					"DOC.DESCRIPCION " +
					"FROM PRODUCTOS.PRDOCUMENTOS_AHORRO PD " +
					"LEFT JOIN NUCLEOCENTRAL.NCDOCUMENTOS DOC ON DOC.ID = PD.DOCUMENTO_ID " +
					"WHERE PD.PRODUCTO_AHORRO_ID = (SELECT ID FROM PRODUCTOS.prproductos_AHORRO WHERE CLAVE = '$PRODUCTO' LIMIT 1)";

			sqlConc = sqlConc.replace("$PRODUCTO", clave);
			System.out.println(sqlConc);

			ResultSet res = stCero.executeQuery(sqlConc);
			while(res.next()){
				TiposDocumentosOBJ obj = new TiposDocumentosOBJ();
				obj.setDocumento_id(res.getInt("DOCUMENTO_ID"));
				obj.setClave(res.getString("CLAVE"));
				obj.setDescripcion(res.getString("DESCRIPCION"));
				obj.setObligatorio(res.getString("OBLIGATORIO"));

				if(lst == null) lst = new ArrayList<>();
				lst.add(obj);
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return lst;
	}

	private static List<ExpedientesOBJ> getExpedientes(Statement stCero, String cuenta){
		List<ExpedientesOBJ> lst = null;
		System.out.println(".... OBTIENE LOS EXPEDIENTES DE LA CUENTA");
		try{
			String sqlConc = "SELECT " +
					"CTA.ID, " +
					"CTA.CUENTA, " +
					"CTA.ESTATUS_ID, " +
					"ESA.DESCRIPCION AS ESTATUS, " +
					"PD.DOCUMENTO_ID, " +
					"DOC.CLAVE, " +
					"DOC.DESCRIPCION, " +
					"PD.OBLIGATORIO, " +
					"EX.ESTATUS_ID AS ESTATUS_EXP_ID, " +
					"ESN.DESCRIPCION AS ESTATUS_EXP, " +
					"EX.VERIFICADO, " +
					"TO_CHAR(EX.FECHA_VERIFICADO, 'YYYY-MM-DD') AS FECHA_VERIFICADO, " +
					"EX.OBSERVACIONES " +
					"FROM AHORRO.AHEXPEDIENTE EX " +
					"LEFT JOIN PRODUCTOS.PRDOCUMENTOS_AHORRO PD ON PD.ID = EX.DOCUMENTOS_AHORRO_ID " +
					"LEFT JOIN NUCLEOCENTRAL.NCDOCUMENTOS DOC ON DOC.ID = PD.DOCUMENTO_ID " +
					"LEFT JOIN AHORRO.AHCUENTAS CTA ON CTA.ID = EX.CUENTA_ID  " +
					"LEFT JOIN AHORRO.AHESTATUS ESA ON ESA.ID = CTA.ESTATUS_ID " +
					"LEFT JOIN NUCLEOCENTRAL.NCESTATUS ESN ON ESN.ID = EX.ESTATUS_ID " +
					"WHERE CTA.CUENTA = '$CUENTA' " +
					"AND EX.ESTATUS_ID NOT IN (SELECT ID FROM NUCLEOCENTRAL.NCESTATUS WHERE DESCRIPCION = 'BAJA' LIMIT 1)";

			sqlConc = sqlConc.replace("$CUENTA", cuenta);
			System.out.println(sqlConc);

			ResultSet res = stCero.executeQuery(sqlConc);
			while(res.next()){
				ExpedientesOBJ obj = new ExpedientesOBJ();
				obj.setId(res.getInt("ID"));
				obj.setCuenta(res.getString("CUENTA"));
				obj.setEstatus_id(res.getInt("ESTATUS_ID"));
				obj.setEstatus(res.getString("ESTATUS"));
				obj.setDocumento_id(res.getInt("DOCUMENTO_ID"));
				obj.setClave(res.getString("CLAVE"));
				obj.setDescripcion(res.getString("DESCRIPCION"));
				obj.setObligatorio(res.getString("OBLIGATORIO"));
				obj.setEstatus_exp_id(res.getInt("ESTATUS_EXP_ID"));
				obj.setEstatus_exp(res.getString("ESTATUS_EXP"));
				obj.setVerificado(res.getString("VERIFICADO"));
				obj.setFecha_verificado(res.getString("FECHA_VERIFICADO"));
				obj.setObservaciones(res.getString("OBSERVACIONES"));

				if(lst == null) lst = new ArrayList<>();
				lst.add(obj);
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return lst;
	}

	private static ExpedientesOBJ getExpediente(Statement stCero, String cuenta, String claveDoc){
		ExpedientesOBJ obj = null;
		System.out.println(".... OBTIENE EXPEDIENTE DE LA CUENTA");
		try{
			String sqlConc = "SELECT " +
					"CTA.ID, " +
					"CTA.CUENTA, " +
					"CTA.ESTATUS_ID, " +
					"ESA.DESCRIPCION AS ESTATUS, " +
					"PD.DOCUMENTO_ID, " +
					"DOC.CLAVE, " +
					"DOC.DESCRIPCION, " +
					"PD.OBLIGATORIO, " +
					"EX.ESTATUS_ID AS ESTATUS_EXP_ID, " +
					"ESN.DESCRIPCION AS ESTATUS_EXP, " +
					"EX.VERIFICADO, " +
					"TO_CHAR(EX.FECHA_VERIFICADO, 'YYYY-MM-DD') AS FECHA_VERIFICADO, " +
					"EX.OBSERVACIONES " +
					"FROM AHORRO.AHEXPEDIENTE EX " +
					"LEFT JOIN PRODUCTOS.PRDOCUMENTOS_AHORRO PD ON PD.ID = EX.DOCUMENTOS_AHORRO_ID " +
					"LEFT JOIN NUCLEOCENTRAL.NCDOCUMENTOS DOC ON DOC.ID = PD.DOCUMENTO_ID " +
					"LEFT JOIN AHORRO.AHCUENTAS CTA ON CTA.ID = EX.CUENTA_ID  " +
					"LEFT JOIN AHORRO.AHESTATUS ESA ON ESA.ID = CTA.ESTATUS_ID " +
					"LEFT JOIN NUCLEOCENTRAL.NCESTATUS ESN ON ESN.ID = EX.ESTATUS_ID " +
					"WHERE CTA.CUENTA = '$CUENTA' " +
					"AND DOC.CLAVE = '$TIPO_DOC' " +
					"AND EX.ESTATUS_ID NOT IN (SELECT ID FROM NUCLEOCENTRAL.NCESTATUS WHERE DESCRIPCION = 'BAJA' LIMIT 1) " +
					"LIMIT 1";

			sqlConc = sqlConc.replace("$CUENTA", cuenta).replace("$TIPO_DOC", claveDoc);
			System.out.println(sqlConc);

			ResultSet res = stCero.executeQuery(sqlConc);
			while(res.next()){
				if(obj == null) obj = new ExpedientesOBJ();
				obj.setId(res.getInt("ID"));
				obj.setCuenta(res.getString("CUENTA"));
				obj.setEstatus_id(res.getInt("ESTATUS_ID"));
				obj.setEstatus(res.getString("ESTATUS"));
				obj.setDocumento_id(res.getInt("DOCUMENTO_ID"));
				obj.setClave(res.getString("CLAVE"));
				obj.setDescripcion(res.getString("DESCRIPCION"));
				obj.setObligatorio(res.getString("OBLIGATORIO"));
				obj.setEstatus_exp_id(res.getInt("ESTATUS_EXP_ID"));
				obj.setEstatus_exp(res.getString("ESTATUS_EXP"));
				obj.setVerificado(res.getString("VERIFICADO"));
				obj.setFecha_verificado(res.getString("FECHA_VERIFICADO"));
				obj.setObservaciones(res.getString("OBSERVACIONES"));
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return obj;
	}


	@SuppressWarnings("unused")
	private static List<CuentasOBJ> getCuenta(Connection conCero, Statement stProcrea, Statement stCero, String productoBlu, String fechaHoy, Integer diasTolerancia){
		System.out.println(".... OBTIENE LOS DATOS DE LA CUENTA");
		List<CuentasOBJ> lst = null;
		try{
			String sqlConc = "SELECT " + 
					"CTA.ID, " +
					"CTA.CUENTA, " +
					"CTA.REFERENCIA, " +
					"CTA.CLABE_INTERBANCARIA, " +
					"CTA.PERSONA_ID, " +
					"TO_CHAR(CTA.FECHA_APERTURA, 'YYYY-MM-DD') AS FECHA_APERTURA, " +
					"CTA.ESTATUS_ID, " +
					"ESA.DESCRIPCION AS ESTATUS, " +
					"CTA.BLOQUEADO_ID, " +
					"ESN.DESCRIPCION AS BLOQUEADO, " +
					"CTA.CLABE_EJE, " +
					"CTA.TIPO_CLIENTE  " +
					"FROM AHORRO.AHCUENTAS CTA " + 
					"LEFT JOIN AHORRO.AHESTATUS ESA ON ESA.ID = CTA.ESTATUS_ID " + 
					"LEFT JOIN NUCLEOCENTRAL.NCESTATUS ESN ON ESN.ID = CTA.BLOQUEADO_ID " + 
					"LEFT JOIN PRODUCTOS.PRPRODUCTOS_AHORRO PR ON PR.ID = CTA.PRODUCTO_AHORRO_ID " +
					"WHERE PR.CLAVE = '$PRODUCTO' " +
					"AND CTA.ESTATUS_ID = (SELECT ID FROM AHORRO.AHESTATUS WHERE CLAVE = 'VIG' LIMIT 1) " +
					"AND (CTA.BLOQUEADO_ID IS NULL OR CTA.BLOQUEADO_ID = (SELECT ID FROM NUCLEOCENTRAL.NCESTATUS WHERE DESCRIPCION = 'TRAMITE' LIMIT 1))";

			sqlConc = sqlConc.replace("$PRODUCTO", productoBlu);
			System.out.println(sqlConc);

			ResultSet res = stCero.executeQuery(sqlConc);
			while(res.next()){
				CuentasOBJ obj = new CuentasOBJ();
				obj.setId(res.getInt("ID"));
				obj.setCuenta(res.getString("CUENTA"));
				obj.setReferencia(res.getString("REFERENCIA"));
				obj.setClabe_interbancaria(res.getString("CLABE_INTERBANCARIA"));
				obj.setPersona_id(res.getString("PERSONA_ID"));
				obj.setFecha_apertura(res.getString("FECHA_APERTURA"));
				obj.setEstatus_id(res.getInt("ESTATUS_ID"));
				obj.setEstatus(res.getString("ESTATUS"));
				obj.setBloqueado_id(res.getInt("BLOQUEADO_ID"));
				obj.setBloqueado(res.getString("BLOQUEADO"));
				obj.setClabe_eje(res.getString("CLABE_EJE"));
				obj.setTipoCliente(res.getString("TIPO_CLIENTE"));

				Integer diasHab = getDiasHabiles(stProcrea, obj.getFecha_apertura(), fechaHoy);

				System.out.println(String.format("....Analizando ... \nCUENTA %s, \nFEC_APERTURA %s, \nHOY %s, \nDIAS TOLER %d, \nDIAS HABILES %d ",
						obj.getCuenta(), obj.getFecha_apertura(), fechaHoy, diasTolerancia, diasHab));

				if(_I(diasHab).intValue() > _I(diasTolerancia).intValue()){
					System.out.println(String.format("..Incluyendo................ \nCUENTA %s", obj.getCuenta()));
					Boolean ok = getBloqueaCuenta(conCero, obj.getCuenta(), productoBlu , _TRANSACCION_, fechaHoy);

					if(lst ==  null) lst = new ArrayList<>();
					lst.add(obj);
					
					if("CUENTA_BLU".equals(_T(obj.getTipoCliente()))){
						List<CuentasOBJ> lstDep = getCuentasDependientes(conCero, obj);
						if(lstDep != null){
							for(CuentasOBJ ctaDep : lstDep){
								Boolean okDep = getBloqueaCuenta(conCero, ctaDep.getCuenta(), productoBlu , _TRANSACCION_, fechaHoy);
								
								if(obj.getDependientes() == null) obj.iniciaDependientes();
								obj.getDependientes().add(ctaDep);
							}
						}
					}
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return lst;
	}

	private static List<CuentasOBJ> getCuentasDependientes(Connection conCero, CuentasOBJ objPadre){
		System.out.println(".... OBTIENE LOS DATOS DE LA CUENTA DEPENDIENTES DE : " + objPadre.getCuenta());
		List<CuentasOBJ> lst = null;
		
		Statement stCero = null;
		try{
			stCero = conCero.createStatement();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		try{
			String sqlConc = "SELECT " + 
					"CTA.ID, " +
					"CTA.CUENTA, " +
					"CTA.REFERENCIA, " +
					"CTA.CLABE_INTERBANCARIA, " +
					"CTA.PERSONA_ID, " +
					"TO_CHAR(CTA.FECHA_APERTURA, 'YYYY-MM-DD') AS FECHA_APERTURA, " +
					"CTA.ESTATUS_ID, " +
					"ESA.DESCRIPCION AS ESTATUS, " +
					"CTA.BLOQUEADO_ID, " +
					"ESN.DESCRIPCION AS BLOQUEADO, " +
					"CTA.CLABE_EJE, " +
					"CTA.TIPO_CLIENTE  " +
					"FROM AHORRO.AHCUENTAS CTA " + 
					"LEFT JOIN AHORRO.AHESTATUS ESA ON ESA.ID = CTA.ESTATUS_ID " + 
					"LEFT JOIN NUCLEOCENTRAL.NCESTATUS ESN ON ESN.ID = CTA.BLOQUEADO_ID " + 
					"WHERE CTA.CLABE_EJE = '$CLABE_PADRE'";
			
			sqlConc = sqlConc.replace("$CLABE_PADRE", objPadre.getClabe_interbancaria());
			System.out.println(sqlConc);

			ResultSet res = stCero.executeQuery(sqlConc);
			while(res.next()){
				CuentasOBJ obj = new CuentasOBJ();
				obj.setId(res.getInt("ID"));
				obj.setCuenta(res.getString("CUENTA"));
				obj.setReferencia(res.getString("REFERENCIA"));
				obj.setClabe_interbancaria(res.getString("CLABE_INTERBANCARIA"));
				obj.setPersona_id(res.getString("PERSONA_ID"));
				obj.setFecha_apertura(res.getString("FECHA_APERTURA"));
				obj.setEstatus_id(res.getInt("ESTATUS_ID"));
				obj.setEstatus(res.getString("ESTATUS"));
				obj.setBloqueado_id(res.getInt("BLOQUEADO_ID"));
				obj.setBloqueado(res.getString("BLOQUEADO"));
				obj.setClabe_eje(res.getString("CLABE_EJE"));
				obj.setTipoCliente(res.getString("TIPO_CLIENTE"));
				obj.setCuenta_depende(objPadre.getCuenta());
				obj.setClabe_interbancaria_depende(objPadre.getClabe_interbancaria());
				
				if(lst ==  null) lst = new ArrayList<>();
				lst.add(obj);
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return lst;
	}



	private static Integer getDiasHabiles(Statement stProcrea, String fechaIni, String fechaFin){
		System.out.println(".... OBTIENE EL NUMERO DE DIAS HABILES (PROCREA) EN UN RANGO DE FECHA");
		Integer diasHabiles = null;
		try{
			String sqlConc = "SELECT count(1) AS DIAS_HABILES FROM " +
					"( " +
					"SELECT CAST(to_char(CAST('$FECHA_INI' AS DATE) + dias, 'DD-MM-YYYY') AS character(10)) AS fecha " +
					"FROM generate_series(0, CAST('$FECHA_FIN' AS DATE) - CAST('$FECHA_INI' AS DATE)) AS dias " +
					"WHERE extract (dow FROM CAST('$FECHA_INI' AS DATE) + dias) NOT IN (0) " +
					"AND (CAST('$FECHA_INI' AS DATE) + dias) NOT in " +
					"(SELECT d.diafestivo " +
					"FROM dfestivo as d " +
					"WHERE d.diafestivo BETWEEN CAST('$FECHA_INI' AS DATE) AND CAST('$FECHA_FIN' AS DATE)) " +
					") AS X";

			sqlConc = sqlConc.replace("$FECHA_INI", fechaIni).replace("$FECHA_FIN", fechaFin);
			System.out.println(sqlConc);

			ResultSet res = stProcrea.executeQuery(sqlConc);
			while(res.next()){
				diasHabiles = res.getInt("DIAS_HABILES");
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return diasHabiles;
	}

	private static Boolean getBloqueaCuenta(Connection conCero, String cuenta, String aplicacion, String transaccion, String hoy){
		Boolean correcto = true;
		Integer  registros = 0;

		System.out.println(".... INGRESA A BLOQUEAR LA CUENTA " + cuenta);

		Statement stCero = null;
		try{
			stCero = conCero.createStatement();
		}catch(Exception ex){
			ex.printStackTrace();
		}

		try{
			String sqlConc1 = "UPDATE AHORRO.AHCUENTAS SET " + 
					"BLOQUEADO_ANTERIOR_ID = BLOQUEADO_ID, " +
					"BLOQUEADO_ID = (SELECT ID FROM NUCLEOCENTRAL.NCESTATUS WHERE DESCRIPCION = 'BLOQUEADO' LIMIT 1), " +
					"FECHA_BLOQUEADO = CAST('$FECHA' AS DATE) " +
					"WHERE CUENTA = '$CUENTA' ";

			sqlConc1 = sqlConc1.replace("$CUENTA", cuenta).replace("$FECHA", hoy);
			System.out.println(sqlConc1);

			stCero.executeUpdate(sqlConc1);

		}catch(Exception ex){
			ex.printStackTrace();
			correcto = false;
			return correcto;
		}


		try{
			/* VERIFICA QUE LA CUENTA EXISTA */
			String sqlConc2 = "SELECT COUNT(1) AS TOTAL FROM NUCLEOCENTRAL.CAT_CANAL_CUENTA " +
					"WHERE CUENTA = '$CUENTA' AND TRANSACCION_CLAVE = '$TRANSACCION' AND APLICATIVO_CLAVE = '$APLICACION' ";

			sqlConc2 = sqlConc2.replace("$CUENTA", cuenta).replace("$TRANSACCION", transaccion).replace("$APLICACION", aplicacion);
			System.out.println(sqlConc2);

			ResultSet res = stCero.executeQuery(sqlConc2);
			while(res.next()){
				registros = res.getInt("TOTAL");
			}
		}catch(Exception ex){
			ex.printStackTrace();
			correcto = false;
			return correcto;
		}

		try{
			if(registros == 0){
				Boolean ins = insertCanales(conCero, cuenta, aplicacion, transaccion, hoy);
			}else{
				Boolean upd = updateCanales(conCero, cuenta, aplicacion, transaccion, hoy);
			}
		}catch(Exception ex){
			ex.printStackTrace();
			correcto = false;
		}
		return correcto;
	}

	private static Boolean insertCanales(Connection conCero, String cuenta, String aplicacion, String transaccion, String hoy){
		Boolean correcto = true;

		Statement stCero = null;
		try{
			stCero = conCero.createStatement();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		try{
			String sqlConc = "INSERT INTO NUCLEOCENTRAL.CAT_CANAL_CUENTA (APLICATIVO_CLAVE, TRANSACCION_CLAVE, CUENTA, ESTATUS, " +
					"USUARIO_CREACION, FECHA_CREACION) " +
					"VALUES('$APLICACION', '$TRANSACCION', '$CUENTA', TRUE, 9, CURRENT_TIMESTAMP)";

			System.out.println(sqlConc);
			sqlConc = sqlConc.replace("$CUENTA", cuenta).replace("$TRANSACCION", transaccion).replace("$APLICACION", aplicacion);
			System.out.println(sqlConc);

			stCero.executeUpdate(sqlConc);
		}catch(Exception ex){
			ex.printStackTrace();
			correcto = false;
		}

		return correcto;
	}

	private static Boolean updateCanales(Connection conCero, String cuenta, String aplicacion, String transaccion, String hoy){
		Boolean correcto = true;

		Statement stCero = null;
		try{
			stCero = conCero.createStatement();
		}catch(Exception ex){
			ex.printStackTrace();
		}

		try{
			String sqlConc = "UPDATE  NUCLEOCENTRAL.CAT_CANAL_CUENTA SET " +
					"ESTATUS = TRUE " +
					"WHERE CUENTA = '$CUENTA' " + 
					"AND APLICATIVO_CLAVE = '$APLICACION' " +
					"AND TRANSACCION_CLAVE = '$TRANSACCION'";
			sqlConc = sqlConc.replace("$CUENTA", cuenta).replace("$TRANSACCION", transaccion).replace("$APLICACION", aplicacion);
			System.out.println(sqlConc);

			stCero.executeUpdate(sqlConc);
		}catch(Exception ex){
			ex.printStackTrace();
			correcto = false;
		}

		return correcto;
	}

	private static Boolean insertBitacora(Connection conCero, String dato, String observaciones){
		Boolean correcto = true;

		Statement stCero = null;
		try{
			stCero = conCero.createStatement();
		}catch(Exception ex){
			ex.printStackTrace();
		}

		try{
			String sqlConc = "INSERT INTO NUCLEOCENTRAL.NCBITACORA (TIPO_BITACORA_ID, DATO, OBSERVACIONES, USUARIO_CREACION, FECHA_CREACION) " +
					"VALUES ( " +
					"(SELECT ID FROM NUCLEOCENTRAL.NCTIPOS_BITACORA WHERE CLAVE = 'BLOQUEO_CTA_BLU' LIMIT 1), " +
					"'$DATO', " +
					"'$OBSERVACIONES', " +
					"9, CURRENT_TIMESTAMP)";

			System.out.println(sqlConc);
			sqlConc = sqlConc.replace("$DATO", dato).replace("$OBSERVACIONES", observaciones);
			System.out.println(sqlConc);

			stCero.executeUpdate(sqlConc);
		}catch(Exception ex){
			ex.printStackTrace();
			correcto = false;
		}

		return correcto;
	}

	/*
	 INSERT INTO NUCLEOCENTRAL.NCBITACORA (TIPO_BITACORA_ID, DATO, OBSERVACIONES, USUARIO_CREACION, FECHA_CREACION)
VALUES (
(SELECT ID FROM NUCLEOCENTRAL.NCTIPOS_BITACORA WHERE CLAVE = 'BLOQUEO_CTA_BLU' LIMIT 1),
'CTA : 111222333444',
'BLOQUEO DE CUENTA POR XXXXXXX',
9, CURRENT_TIMESTAMP);
	 */
	private static String _T(Object obj){
		return obj == null ? null : String.valueOf(obj);
	}

	public static Integer _I(Object obj) {
		return obj == null ? 0 : Integer.parseInt(obj.toString());
	}

}
