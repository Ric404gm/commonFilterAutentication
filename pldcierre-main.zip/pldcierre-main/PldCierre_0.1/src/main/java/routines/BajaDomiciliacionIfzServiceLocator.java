/**
 * BajaDomiciliacionIfzServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package routines;

public class BajaDomiciliacionIfzServiceLocator extends org.apache.axis.client.Service implements routines.BajaDomiciliacionIfzService {

    public BajaDomiciliacionIfzServiceLocator() {
    }


    public BajaDomiciliacionIfzServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public BajaDomiciliacionIfzServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for BajaDomiciliacionIfzPort
    private java.lang.String BajaDomiciliacionIfzPort_address = "http://sr-mule.integraopciones.mx:10081/esb/credito/baja-domiciliacion";

    public java.lang.String getBajaDomiciliacionIfzPortAddress() {
        return BajaDomiciliacionIfzPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String BajaDomiciliacionIfzPortWSDDServiceName = "BajaDomiciliacionIfzPort";

    public java.lang.String getBajaDomiciliacionIfzPortWSDDServiceName() {
        return BajaDomiciliacionIfzPortWSDDServiceName;
    }

    public void setBajaDomiciliacionIfzPortWSDDServiceName(java.lang.String name) {
        BajaDomiciliacionIfzPortWSDDServiceName = name;
    }

    public routines.BajaDomiciliacionIfz getBajaDomiciliacionIfzPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(BajaDomiciliacionIfzPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getBajaDomiciliacionIfzPort(endpoint);
    }

    public routines.BajaDomiciliacionIfz getBajaDomiciliacionIfzPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            routines.BajaDomiciliacionIfzServiceSoapBindingStub _stub = new routines.BajaDomiciliacionIfzServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getBajaDomiciliacionIfzPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setBajaDomiciliacionIfzPortEndpointAddress(java.lang.String address) {
        BajaDomiciliacionIfzPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (routines.BajaDomiciliacionIfz.class.isAssignableFrom(serviceEndpointInterface)) {
                routines.BajaDomiciliacionIfzServiceSoapBindingStub _stub = new routines.BajaDomiciliacionIfzServiceSoapBindingStub(new java.net.URL(BajaDomiciliacionIfzPort_address), this);
                _stub.setPortName(getBajaDomiciliacionIfzPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("BajaDomiciliacionIfzPort".equals(inputPortName)) {
            return getBajaDomiciliacionIfzPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://bajaDomiciliacion.cr.ws.izel.net/", "BajaDomiciliacionIfzService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://bajaDomiciliacion.cr.ws.izel.net/", "BajaDomiciliacionIfzPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("BajaDomiciliacionIfzPort".equals(portName)) {
            setBajaDomiciliacionIfzPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
